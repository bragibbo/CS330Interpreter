const ParserTests = require("./parserTests").RunParserTests

module.exports.TestRunner = () => {
  ParserTests()
}